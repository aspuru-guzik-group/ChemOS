Funniest
--------

To use (with caution), simply do::

    >>> import funniest
    >>> print funniest.joke()
